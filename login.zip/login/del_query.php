<?php
session_start();
include('connection.php');

$id = $_SESSION['id'];
$date1 = $_GET['date1'];
$stime = $_GET['stime'];
$etime = $_GET['etime'];
$dayNo = $_GET['dayNo'];
$query = $_GET['query'];
$str = "";
$like = $_SESSION['ulike'];
$ulike = "";

for($i = 0; $i < strlen($like); $i++){
if()

}




?>