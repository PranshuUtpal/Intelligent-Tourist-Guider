<?php
session_destroy();

header('location:/labpro3/index.html');
?>